# Readme.md
1. npm install
2. npm run dev
3. open the  http://localhost:8080/ in local